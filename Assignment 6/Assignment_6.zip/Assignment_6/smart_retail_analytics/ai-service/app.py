"""
Smart Retail Analytics Platform - FastAPI Model-Serving Backend
Subject: Advanced Data Science Laboratory (PEIT412B) - Practical 06
"""

import os
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
from model import RetailAnalyticsModel
import uvicorn

app = FastAPI(
    title="Smart Retail Analytics AI API",
    description="Multi-service AI engine for footfall counting and stock monitoring",
    version="1.0.0"
)

model = RetailAnalyticsModel()

class FootfallInput(BaseModel):
    footfall_count: int = Field(..., example=180, description="Current footfall count in store")
    store_capacity: int = Field(250, example=250, description="Maximum total capacity")

class StockInput(BaseModel):
    shelf_stock_pct: float = Field(..., example=28.5, description="Current stock level percentage (0-100)")
    category: str = Field(..., example="Dairy & Eggs")

@app.get('/')
def root():
    return {
        "service": "Smart Retail Analytics AI Engine",
        "status": "online",
        "container": "ai-service",
        "documentation": "/docs"
    }

@app.get('/health')
def health():
    return {"status": "healthy", "service": "retail-ai-service"}

@app.post('/predict/footfall')
def predict_footfall(item: FootfallInput):
    result = model.predict_occupancy_risk(item.footfall_count, item.store_capacity)
    return {"success": True, "analysis": result}

@app.post('/predict/stock')
def predict_stock(item: StockInput):
    result = model.predict_stock_replenishment(item.shelf_stock_pct, item.category)
    return {"success": True, "analysis": result}

if __name__ == '__main__':
    port = int(os.environ.get('PORT', 5000))
    uvicorn.run(app, host='0.0.0.0', port=port)
