"""
Smart Retail Analytics Platform - ML Model Inference Module
Subject: Advanced Data Science Laboratory (PEIT412B) - Practical 06
"""

import numpy as np

class RetailAnalyticsModel:
    def predict_occupancy_risk(self, footfall_count: int, store_capacity: int = 250):
        occupancy_pct = (footfall_count / store_capacity) * 100.0
        
        if occupancy_pct > 85.0:
            status = "CRITICAL_OVERCROWDING"
            risk = "HIGH"
            action = "Dispatch security team to manage store entry queues."
        elif occupancy_pct > 70.0:
            status = "HIGH_CAPACITY"
            risk = "MEDIUM"
            action = "Open additional checkout counters."
        else:
            status = "NORMAL_FLOW"
            risk = "LOW"
            action = "Normal operations."
            
        return {
            "footfall_count": footfall_count,
            "store_capacity": store_capacity,
            "occupancy_rate_pct": round(occupancy_pct, 2),
            "status": status,
            "risk_level": risk,
            "recommended_action": action
        }

    def predict_stock_replenishment(self, shelf_stock_pct: float, category: str):
        need_restock = shelf_stock_pct < 35.0
        urgency = "URGENT" if shelf_stock_pct < 20.0 else ("MODERATE" if shelf_stock_pct < 35.0 else "OPTIMAL")
        
        return {
            "category": category,
            "shelf_stock_pct": shelf_stock_pct,
            "restock_required": need_restock,
            "urgency_level": urgency,
            "suggested_units": int((100.0 - shelf_stock_pct) * 2.5) if need_restock else 0
        }
