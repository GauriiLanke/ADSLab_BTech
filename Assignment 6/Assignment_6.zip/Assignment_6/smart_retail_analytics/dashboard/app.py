"""
Smart Retail Analytics Platform - Streamlit Web Dashboard Service
Subject: Advanced Data Science Laboratory (PEIT412B) - Practical 06
"""

import os
import requests
import pandas as pd
import numpy as np
import streamlit as st

st.set_page_config(
    page_title="Smart Retail Analytics Portal",
    page_icon="🛒",
    layout="wide"
)

st.title("🛒 Smart Retail Analytics Platform")
st.subheader("Containerized Multi-Service AI System | Sanjivani COE")

AI_SERVICE_URL = os.environ.get("AI_SERVICE_URL", "http://ai-service:5000")

col1, col2 = st.columns(2)

with col1:
    st.markdown("### 🚶 Footfall & Store Occupancy Monitor")
    footfall = st.number_input("Real-Time Store Footfall Count", min_value=0, max_value=400, value=185)
    capacity = st.number_input("Total Store Capacity", min_value=50, max_value=1000, value=250)
    
    if st.button("Analyze Store Occupancy Risk", type="primary"):
        try:
            res = requests.post(f"{AI_SERVICE_URL}/predict/footfall", json={"footfall_count": footfall, "store_capacity": capacity}, timeout=3)
            if res.status_code == 200:
                data = res.json()["analysis"]
                st.success(f"Occupancy Rate: {data['occupancy_rate_pct']}% ({data['status']})")
                st.info(f"Recommended Action: {data['recommended_action']}")
            else:
                st.error("API Error")
        except Exception as e:
            # Fallback for local standalone test
            occ = (footfall / capacity) * 100
            st.success(f"Occupancy Rate: {occ:.1f}%")
            st.info(f"Targeting AI Service at: {AI_SERVICE_URL}")

with col2:
    st.markdown("### 📦 Shelf Stock & Inventory Analytics")
    category = st.selectbox("Product Category", ["Fresh Produce", "Dairy & Eggs", "Beverages", "Bakery & Snacks", "Frozen Foods"])
    stock_pct = st.slider("Current Shelf Stock Level (%)", 0.0, 100.0, 24.5)
    
    if st.button("Evaluate Stock Replenishment"):
        try:
            res = requests.post(f"{AI_SERVICE_URL}/predict/stock", json={"shelf_stock_pct": stock_pct, "category": category}, timeout=3)
            if res.status_code == 200:
                data = res.json()["analysis"]
                if data["restock_required"]:
                    st.warning(f"⚠️ Restock Required for {category}! Urgency: {data['urgency_level']}")
                    st.write(f"Suggested Restock Quantity: **{data['suggested_units']} units**")
                else:
                    st.success(f"✅ Stock level for {category} is optimal.")
        except Exception as e:
            st.info(f"Local calculation: Stock Level = {stock_pct}%")

st.divider()
st.markdown("### 🐳 Docker Compose Architecture Stack")
st.write("• **Service 1**: `ai-service` (FastAPI backend on port 5000)")
st.write("• **Service 2**: `db` (PostgreSQL 15 volume persistent store)")
st.write("• **Service 3**: `dashboard` (Streamlit web portal on port 8501)")
