"""
AI Attendance Monitoring System API Server
Subject: Advanced Data Science Laboratory (PEIT412B) - Practical 06
Sanjivani College of Engineering, Kopargaon

Exposes REST endpoints to log facial attendance, query log records, and verify service health inside Docker.
"""

import os
from flask import Flask, request, jsonify
from model import FaceRecognitionInference

app = Flask(__name__)
engine = FaceRecognitionInference()

attendance_log = []

@app.route('/', methods=['GET'])
def index():
    return jsonify({
        "service": "AI Attendance Monitoring Service",
        "container_status": "running",
        "institution": "Sanjivani College of Engineering, Kopargaon",
        "endpoints": {
            "GET /": "Service info",
            "GET /health": "Health check",
            "POST /mark_attendance": "Process camera feature vector & log attendance",
            "GET /attendance_logs": "Retrieve logged attendance"
        }
    })

@app.route('/health', methods=['GET'])
def health():
    return jsonify({"status": "healthy", "service": "ai-attendance-system"})

@app.route('/mark_attendance', methods=['POST'])
def mark_attendance():
    try:
        data = request.get_json(force=True)
        feature_vector = data.get("face_feature_vector", [0.45, 0.82, 0.19, 0.64])
        
        result = engine.predict_face(feature_vector)
        
        if result["match_found"]:
            attendance_log.append(result)
            return jsonify({
                "success": True,
                "message": f"Attendance marked for {result['name']} ({result['student_id']})",
                "record": result
            })
        else:
            return jsonify({
                "success": False,
                "message": "Face not recognized. Attendance not marked.",
                "record": result
            }), 404
            
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500

@app.route('/attendance_logs', methods=['GET'])
def get_logs():
    return jsonify({
        "total_records": len(attendance_log),
        "logs": attendance_log
    })

if __name__ == '__main__':
    port = int(os.environ.get('PORT', 5000))
    app.run(host='0.0.0.0', port=port)
