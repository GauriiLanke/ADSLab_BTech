"""
AI Attendance Monitoring System - Face Recognition & Verification Inference Engine
Subject: Advanced Data Science Laboratory (PEIT412B) - Practical 06
"""

import numpy as np
import pandas as pd
from datetime import datetime

# Known registered student embeddings database simulation
REGISTERED_STUDENTS = {
    "STD001": {"name": "Aarav Sharma", "dept": "Information Technology", "face_feature_centroid": [0.45, 0.82, 0.19, 0.64]},
    "STD002": {"name": "Ananya Patel", "dept": "Information Technology", "face_feature_centroid": [0.12, 0.95, 0.44, 0.23]},
    "STD003": {"name": "Rohan Verma", "dept": "Computer Engineering", "face_feature_centroid": [0.78, 0.33, 0.89, 0.11]},
    "STD004": {"name": "Priya Kulkarni", "dept": "Computer Engineering", "face_feature_centroid": [0.91, 0.22, 0.55, 0.67]},
    "STD005": {"name": "Aditya Joshi", "dept": "Data Science", "face_feature_centroid": [0.33, 0.44, 0.12, 0.88]}
}

class FaceRecognitionInference:
    def __init__(self):
        self.students = REGISTERED_STUDENTS

    def predict_face(self, input_vector):
        """Calculates cosine similarity / Euclidean distance against known centroids."""
        inp = np.array(input_vector, dtype=float)
        best_match = None
        min_distance = float('inf')
        
        for std_id, info in self.students.items():
            centroid = np.array(info['face_feature_centroid'], dtype=float)
            dist = float(np.linalg.norm(inp - centroid))
            if dist < min_distance:
                min_distance = dist
                best_match = std_id
                
        confidence = float(max(0.0, min(100.0, (1.0 - min_distance) * 100)))
        
        if confidence > 55.0 and best_match is not None:
            student_info = self.students[best_match]
            return {
                "match_found": True,
                "student_id": best_match,
                "name": student_info["name"],
                "department": student_info["dept"],
                "confidence": round(confidence, 2),
                "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            }
        else:
            return {
                "match_found": False,
                "student_id": "UNKNOWN",
                "name": "Unrecognized Person",
                "department": "N/A",
                "confidence": round(confidence, 2),
                "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            }
