# Practical No. 06: Scalable AI Systems Deployment using Docker & CI/CD Pipelines

**Sanjivani Rural Education Society’s**  
**Sanjivani College of Engineering, Kopargaon**  
**Department of Information Technology**  
*Class: B. Tech. Semester: VII | Subject: Advanced Data Science Laboratory (PEIT412B)*  

---

## 📌 Project Overview
This repository contains the complete implementation for **Practical No. 06**, covering containerization of machine learning applications using **Docker**, multi-service orchestration via **Docker Compose**, and deployment pipeline integration with **GitHub Actions**.

### 🤖 Case Studies Implemented
1. **AI Attendance Monitoring System**: Single-container face-recognition inference service logging attendance timestamps (`ai_attendance_system/`).
2. **Smart Retail Analytics Platform**: Multi-service AI application combining FastAPI model serving (`ai-service`), PostgreSQL database (`db`), and interactive Streamlit UI (`dashboard`) orchestrated via `docker-compose.yml`.

---

## 📁 Repository Structure
```
Assignment_6/
├── ai_attendance_system/
│   ├── app.py
│   ├── model.py
│   ├── requirements.txt
│   └── Dockerfile
├── smart_retail_analytics/
│   ├── ai-service/
│   │   ├── app.py
│   │   ├── model.py
│   │   ├── requirements.txt
│   │   └── Dockerfile
│   ├── dashboard/
│   │   ├── app.py
│   │   ├── requirements.txt
│   │   └── Dockerfile
│   └── docker-compose.yml
├── datasets/
│   ├── attendance_dataset.csv
│   └── retail_footfall_dataset.csv
├── .github/workflows/
│   └── docker-deploy.yml
├── test_services.py
├── Assignment_6.ipynb
└── README.md
```

---

## 🚀 How to Run the Containerized Applications

### 1. Build and Run AI Attendance Service (Single Container)
```bash
cd ai_attendance_system
docker build -t ai-attendance-system:latest .
docker run -p 5000:5000 ai-attendance-system:latest
```

### 2. Run Smart Retail Analytics Stack (Multi-Container Docker Compose)
```bash
cd smart_retail_analytics
docker compose up --build
```
*Exposed Services:*
- **AI Analytics Service**: `http://localhost:5000`
- **PostgreSQL Database**: `localhost:5432`
- **Streamlit Dashboard**: `http://localhost:8501`

### 3. Test Local Python Services
```bash
python test_services.py
```

---

## ⚙️ GitHub Actions CI/CD Pipeline
The workflow in `.github/workflows/docker-deploy.yml` performs:
1. Automated Python code linting (`flake8`).
2. Parallel Docker image building for all container services.
3. Docker Compose stack configuration validation (`docker compose config`).
4. Automated pushing to Docker Hub on push to `main` branch.
